import NextAuth, { NextAuthOptions } from "next-auth"
import GoogleProvider from "next-auth/providers/google"
import GitHubProvider from "next-auth/providers/github"
import LinkedInProvider from "next-auth/providers/linkedin"

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || "placeholder-id",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "placeholder-secret",
    }),
    GitHubProvider({
      clientId: process.env.GITHUB_ID || "placeholder-id",
      clientSecret: process.env.GITHUB_SECRET || "placeholder-secret",
    }),
    LinkedInProvider({
      clientId: process.env.LINKEDIN_CLIENT_ID || "placeholder-id",
      clientSecret: process.env.LINKEDIN_CLIENT_SECRET || "placeholder-secret",
      authorization: {
        params: {
          scope: "openid profile email",
        },
      },
    }),
  ],
  secret: process.env.NEXTAUTH_SECRET || "placeholder-secret-change-in-production",
  callbacks: {
    async jwt({ token, account, profile }) {
      // Store OAuth tokens in JWT
      if (account) {
        ;(token as any).provider = account.provider
        if (account.provider === "github") {
          ;(token as any).githubAccessToken = account.access_token
        }
        if (account.provider === "linkedin") {
          ;(token as any).linkedinAccessToken = account.access_token
        }
        if (account.provider === "google") {
          // Google doesn't provide additional scopes for connecting accounts
          // But we store the provider info
        }
      }
      return token
    },
    async session({ session, token }) {
      // Add tokens to session
      if ((token as any).githubAccessToken) {
        ;(session as any).githubAccessToken = (token as any).githubAccessToken
      }
      if ((token as any).linkedinAccessToken) {
        ;(session as any).linkedinAccessToken = (token as any).linkedinAccessToken
      }
      // Store provider info
      if ((token as any).provider) {
        ;(session as any).provider = (token as any).provider
      }
      return session
    },
    async redirect({ url, baseUrl }) {
      // If callbackUrl is provided and is a relative URL, use it
      if (url.startsWith("/")) {
        return `${baseUrl}${url}`
      }
      // If url is on the same origin, allow it
      if (url.startsWith(baseUrl)) {
        return url
      }
      // Default: redirect to dashboard
      return `${baseUrl}/dashboard`
    },
  },
}

export const authHandler = NextAuth(authOptions)

