import { authHandler } from "@/lib/auth"

export { authHandler as GET, authHandler as POST }
