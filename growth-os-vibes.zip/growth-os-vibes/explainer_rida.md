# Growth OS

**Product Name:** Growth OS  
**One-line Description:** An AI-powered career progression engine that analyzes your GitHub, resume, and portfolio to generate a personalized gap analysis and 90-day action plan — free, no sign-up required.

**Team Members:**
- Rida Khan — reach.rida.khan@gmail.com

**Live URL:** https://growth-os-lake.vercel.app/
**GitHub:** https://github.com/Rida-ds-hub/GrowthOS-

---

## Problem Solved

Most tech professionals have ambition but zero architecture for career growth. They guess at which skills to build, when to push for a promotion, and how to make their work visible — and they guess wrong. Growth OS solves this by ingesting real professional data (GitHub repos, resume, portfolio site) and running an AI-powered gap analysis across five career domains: System Design Maturity, Execution Scope, Communication & Visibility, Technical Depth, and Leadership & Influence. It then generates a personalized 90-day roadmap with concrete phase-by-phase actions, upskilling project recommendations, a posting strategy, and a promotion narrative — all downloadable as a report, all completely free.
